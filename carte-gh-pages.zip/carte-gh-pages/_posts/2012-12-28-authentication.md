---
url_path: '/login'
title: 'Authenticate'

layout: null
---

This method allows users to retrieve stuff.

### Response

Sends back a collection of things.

```Authentication: bearer TOKEN```
```{
    id: thing_2,
    name: 'My second thing'
}```

For errors responses, see the [response status codes documentation](#response-status-codes).
